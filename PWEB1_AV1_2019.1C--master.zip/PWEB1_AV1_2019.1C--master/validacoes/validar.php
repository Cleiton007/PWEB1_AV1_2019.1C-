<?php
	require_once("variaveis.php");
	function __e($input){
		$input = trim($input);
		$input = stripcslashes($input);
		$input = htmlspecialchars($input);
		
		return $input;
	}
	
	$nome = __e($_POST["nome"]);
	$email = __e($_POST["email"]);
	$telefone = __e($_POST["telefone"]);
	$opcao = __e($_POST["opcao"]);
	$tipo_cliente = __e($_POST["tipo_cliente"]);
	$receber_ligacao = __e($_POST["receber_ligacao"]);
	$mensagem = __e($_POST["mensagem"]);
	
			if(empty($nome) || empty($email) || empty($mensagem) || isset($tipo_cliente) == null){
					echo "Preencha os campos com *";
			}
			if(strlen($nome) <10){
				echo "O campo nome deve ser preenchido com no mínimo 10 caracteres!<br>";
			}
			if(strlen($email) <25){
				echo "O campo email deve ser preenchido com no mínimo 25 caracteres!<br>";
			}
			if(strlen($telefone) <11){
				echo "Insira o DDD do telefone!<br>"
			}
?>